package trafficLights;

public enum Light {

    RED,
    GREEN,
    YELLOW;
}