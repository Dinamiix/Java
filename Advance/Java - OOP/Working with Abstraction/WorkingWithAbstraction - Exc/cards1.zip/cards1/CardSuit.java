package cards1;

public enum CardSuit {

    // Енъм стойности
    // Ordinal value -> поредна стойност/позиция на енъм стойността
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;

}