package stackofstrings;

public class Main {
    public static void main(String[] args) {
        StackOfStrings strings = new StackOfStrings();
    }
}