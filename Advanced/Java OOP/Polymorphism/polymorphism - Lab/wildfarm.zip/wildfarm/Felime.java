package wildfarm;

public abstract class Felime extends wildfarm.Mammal {
    protected Felime(String name, String type, Double weight, String livingRegion) {
        super(name, type, weight, livingRegion);
    }
}