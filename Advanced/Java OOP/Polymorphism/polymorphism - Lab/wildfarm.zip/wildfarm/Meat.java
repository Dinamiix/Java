package wildfarm;

public class Meat extends wildfarm.Food {
    public Meat(Integer quantity) {
        super(quantity);
    }
}