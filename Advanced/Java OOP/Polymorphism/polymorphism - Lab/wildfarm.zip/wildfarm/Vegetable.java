package wildfarm;

public class Vegetable extends wildfarm.Food {
    public Vegetable(Integer quantity) {
        super(quantity);
    }
}