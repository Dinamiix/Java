package shapes;

public interface Shape {
    Double calculatePerimeter();
    Double calculateArea();
}