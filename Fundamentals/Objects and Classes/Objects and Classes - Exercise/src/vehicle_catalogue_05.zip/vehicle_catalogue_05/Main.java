package vehicle_catalogue_05;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        List<Vehicle> vehicles = new ArrayList<>();

        String input = scanner.nextLine();
        while (!input.equals("End")) {
            String[] rowElements = input.split("\\s+");
            vehicles.add(new Vehicle(rowElements[0], rowElements[1],rowElements[2], Integer.parseInt(rowElements[3])));
            input = scanner.nextLine();
        }

        String model = scanner.nextLine();
        while (!model.equals("Close the Catalogue")) {
            for (Vehicle vehicle : vehicles) {
                if (vehicle.getModel().equals(model)) {
                    System.out.println(vehicle);
                }
            }
            model = scanner.nextLine();
        }
        double sumCar = 0;
        double sumTruck = 0;
        int countCar = 0;
        int countTruck = 0;

        for (Vehicle vehicle : vehicles) {
            if (vehicle.getType().equals("car")){
                sumCar += vehicle.getHorsePower();
                countCar++;
            } else if (vehicle.getType().equals("truck")) {
                sumTruck += vehicle.getHorsePower();
                countTruck++;

            }
        }

        double averageCars = sumCar / countCar;
        if (countCar == 0) {
            averageCars = 0;
        }
        System.out.printf("Cars have average horsepower of: %.2f.%n", averageCars);

        double averageTruck = sumTruck / countTruck;
        if (countTruck == 0) {
            averageTruck = 0;
        }
        System.out.printf("Trucks have average horsepower of: %.2f.%n",averageTruck);
    }
}
